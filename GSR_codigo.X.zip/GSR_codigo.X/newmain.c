/*
 * File:   newmain.c
 * Author: 34674
 *
 * Created on 6 de junio de 2023, 18:15
 */


#include <xc.h>

void main(void) {
    return;
}
